//Amanda Potenza
//Prog 3
//2/9/23 before 10:30 am
//Purpose: This program is designed to automate the processing of insurance payments for several patients
//
//input: Patient IDs, Household income, Insurance plan, Number of days
//output:  Patient ID, Household income (validated), Insurance plan(validated), Number of days(validated), 
//         Admittance fee, Per Diem rate, Service fee, Discount, and Total bill. 
//		   Also number of patients, highest bill + patient ID associated with it, sum of bills and avg. of bills
//
//Certification of Authenticity: I certify this lab is entirely my own work

import java.util.*;

public class HospitalPotenza 
{

	//declare keyboard for project
	static Scanner keyboard = new Scanner(System.in);
	
	
	public static void main(String[] args) 
	{//main
		
	
		//declare and initialize variables 
		int patientID = 0;
		double income = 0;
		char insurancePlan;
		String insurancePlanFull = "";
		String fakeInsurancePlan = "";
		int days = 0;
		int admittanceFee = 250;
		double serviceFee = 0;
		double perDiemRate = 0;
		double discount = 0;
		double totalBill = 0;	
		int numPatients = 0;
		double highestBill = Integer.MIN_VALUE;
		int highestBillID = 0;
		double sumOfBills = 0;
	
		//Introduce the program and ask user for patientID (or 0 to quit)
		System.out.println("Welcome! This program will help you to more simply calculate insurance payments.");
		System.out.print("Please enter the patient ID or 0 to quit: ");
		patientID = keyboard.nextInt();

		
		//create a while loop for multiple patients
		while (patientID != 0)
		{			
	
			numPatients++; //add 1 to patient count	
			
			
			//Ask user to input income 
			System.out.print("Now please enter the patient's household income: $");
			income = keyboard.nextDouble();
			while (income < 0)
			{
				System.out.print("Invalid input. Try entering another number.");
				income = keyboard.nextDouble();
			}//while -- used to validate income
			
			
			//Ask for patient's insurance plan
			System.out.println("Please specify the patient's insurance plan.");
			System.out.print("Type 'B' for Blue Plus, 'M' for Medhealth, 'H' for Health Plan, and 'N' for no insurance: ");
				fakeInsurancePlan = keyboard.next();
				insurancePlan = fakeInsurancePlan.toUpperCase().charAt(0);

				while ((insurancePlan != 'B')&&(insurancePlan != 'M')&&(insurancePlan != 'H')&&(insurancePlan != 'N'))
				{
					System.out.print("Invalid input. Type 'B' for Blue Plus, 'M' for Medhealth, 'H' for Health Plan, and 'N' for no insurance: ");
					fakeInsurancePlan = keyboard.next();
					insurancePlan = fakeInsurancePlan.toUpperCase().charAt(0);
				}//while -- used to validate income
			
			//Ask for number of days in hospital
			System.out.print("Please type the number of days (0-365) that the patient was in the hospital for: ");
			days = keyboard.nextInt();
			while ((days < 0)||(days > 365))
			{
				System.out.print("Invalid input. Try entering another number from 0-365.");
				days = keyboard.nextInt();
			}//while -- used to validate days
			
			
			
			//assign Per Diem rate based on insurance plan 
			switch (insurancePlan)
			{
			case 'b':
			case 'B':
				if (income < 14000)
					perDiemRate = 40;
				else if (income <= 67500)
					perDiemRate = 75;
				else
					perDiemRate = 150;
				insurancePlanFull = "Blue Plus";
				break;
			case 'm':
			case 'M':
				if (income < 20000)
					perDiemRate = 75;
				else if (income <= 50000)
					perDiemRate = 100;
				else
					perDiemRate = 120;
				insurancePlanFull = "Med-Health";
				break;
			case 'h':
			case 'H':
				if (income < 12500)
					perDiemRate = 65;
				else if (income <= 63000)
					perDiemRate = 80;
				else
					perDiemRate = 150;
				insurancePlanFull = "Health Plan";
				break;
			case 'n':
			case 'N':
				perDiemRate = 500;
				insurancePlanFull = "N/A";
				break;		
			}//switch
			
			//Calculate service fee
			serviceFee = perDiemRate * days;
			
			
			//determine cost by adding admittance fee ($250) and service fee, then subtract the discount for long term patients 
			if (days <= 25)
				totalBill = admittanceFee + serviceFee;
			else
			{
				discount = 200 * (days/7); //determine discount for long term patients
				totalBill = admittanceFee + serviceFee - discount;
			}//if else
			
			
			if (totalBill > highestBill)
				{
				highestBill = totalBill;
				highestBillID = patientID;
				}//if else - finds the highest bill of all patients
				
			System.out.println();
			System.out.println("Here are your results.");
			System.out.println("Patient ID: " + patientID);
			System.out.printf("Household Income: $%.2f", income);
			System.out.println("\nInsurance Plan: " + insurancePlanFull);
			System.out.println("Number of Days: " + days);
			System.out.println("Admittance Fee: $" + admittanceFee);
			System.out.printf("Per Diem Rate: $%.2f", perDiemRate);
			System.out.printf("\nService Fee: $%.2f", serviceFee);
			System.out.printf("\nDiscount: $%.2f", discount);
			System.out.printf("\nTotal Bill: $%.2f", totalBill);

			//add patient's total to overall sum of patients
			sumOfBills += totalBill;
			
			
			System.out.println();
			System.out.print("\nTo enter another user, please enter their patient ID here or 0 to quit:");
			patientID = keyboard.nextInt();
			
		}//while
		
		
	//if 0 patients are calculated, no data is shown. Otherwise, program displays a summary of the session.
	if (numPatients == 0)
		System.out.println("You have collected data from 0 patients. No data can be shown. Goodbye. ");
	
	else
	{
		System.out.println();
		System.out.println("Thank you for using this program. Here is a rundown of your data.");
		System.out.println("Number of Patients: " + numPatients);
		System.out.printf("Highest bill was $%.2f " + "paid by the patient ID " + highestBillID, (highestBill));
		System.out.printf("\nTotal sum of all the bills: $%.2f", (sumOfBills));
		System.out.printf("\nAverage bill amount: $%.2f", (sumOfBills / numPatients));
		System.out.println("\nGoodbye!");
	}//if else
	
		
	keyboard.close();
	}//main
}//Changemaker
