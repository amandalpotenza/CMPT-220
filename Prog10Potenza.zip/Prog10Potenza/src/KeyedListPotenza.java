/**
 * 
 * @author Amanda Potenza
 *
 *This is the class definition for KeyedListPotenza <br>
 *This class holds and stores "items"
 */

public class KeyedListPotenza {
	/**
	 * Instance variable for the linked list's head
	 */
	private NodePotenza myHead;

/**
 * The null/default constructor for KeyedListPotenza	
 */	
public KeyedListPotenza()
	{
	myHead = null;
	}//KeyedListPotenza

/**
 * setter for head
 * 
 * @param new node for head
 */
public void setHead(NodePotenza newHead)
	{
	myHead = newHead;
	}//setHead

/**
 * the getter for head
 * 
 * @return current node of myHead
 */
public NodePotenza getHead()
	{
	return myHead;
	}//getHead

/**
 *clear() clears the array by setting size to 0
 */
public void clear()
	{
	myHead = null;
	}//clear

/**
 * Adds song object to the linked list
 * @param newItem	the new item object we want to add
 * @return	boolean describing whether the song was added or not
 */
public boolean add(ItemPotenza newItem)
	{
	boolean found = false;
	NodePotenza curr = myHead;
	NodePotenza prev = null;
	NodePotenza newGuy = null;
	
	//check for duplicates
	if(retrieve(newItem.getName()) == null)
		{
		newGuy = new NodePotenza(newItem);
		
		//find where it goes
		while ((curr != null)&&(!found))
			{
			if (curr.getItem().getName().compareToIgnoreCase(newItem.getName()) > 0)
				found = true;
			else
				{
				prev = curr;
				curr = curr.getNext();
				}//else
			}//while
		found = true;
		
		//update references
		newGuy.setNext(curr);
		
		if (prev == null)
			{
			myHead = newGuy;
			}//if
		else prev.setNext(newGuy);
		}//if
	else System.out.println("Error: duplicate");
	
	return found;
	}//add

/**
 * Deletes song object from myList array
 * 
 * @param keyValue the name of the item name we want to delete
 * @return boolean describing whether the song was deleted or not
 */
public boolean remove(String keyValue)
	{
	NodePotenza curr = myHead;
	NodePotenza prev = null;
	boolean found = false;
	
	//find the target
	while((curr != null) && (!found))
		if (curr.getItem().getName().equalsIgnoreCase(keyValue))
			found = true;
		else
			{
			prev = curr;
			curr = curr.getNext();
			}//else
	
	//update references
	if (found)
		{
		if(prev == null)
			myHead = curr.getNext(); //first or only
		else
			prev.setNext(curr.getNext()); //middle or last
		}//if 
	
	return found;
	}//remove

/**
 * Returns the item with a specified key value
 * 
 * @param keyValue	 Item name we want to find
 * @return	Corresponding item object, or null if not found
 */
public ItemPotenza retrieve(String keyValue)
	{
	NodePotenza curr = myHead;
	ItemPotenza match = null;
	
	while ((curr != null)&&(match == null))
		if(curr.getItem().getName().equalsIgnoreCase(keyValue))
			match = curr.getItem();
		else 
			{
			curr = curr.getNext();
			}//else
		
	return match;
	}//retrieve

/**
 * Tells whether or not myList is empty
 * 
 * @return boolean telling if the list is empty or not
 */
public boolean isEmpty ()
	{
	return (myHead == null);
	}//isEmpty

/**
 * Tells whether or not myList is full
 * 
 * @return boolean telling if the list is full or not
 */
public boolean isFull()
	{
	return false;
	}//isFull
	
/**
 * prints a String decription of each item in the list
 */
public void print()
	{
	NodePotenza curr = myHead;
	int count = 0;
	
	if (curr != null)
		{
		while(curr != null)
			{
			count ++;
			System.out.println("Item #" + count + ":");
			System.out.println(curr.getItem().toString());
			curr = curr.getNext();
			}
		}//for
	else System.out.println("The shopping list is empty. Try adding some items! ");
	
	}//print

/**
 * Finds total number of items in list
 * @return	total item count
 */
public int getCount()
	{
	NodePotenza curr = myHead;
	int count = 0;
	
	if (curr != null)
		{
		while(curr != null)
			{
			count += curr.getItem().getQuantity();
			curr = curr.getNext();
			}
		}//for
	else System.out.println("The shopping list is empty. Try adding some items! ");
	
	return count;
	}//getCount

/**
 * Finds total cost of items in list
 * @return total cost of items
 */
public double calcTotal()
	{
	NodePotenza curr = myHead;
	double total = 0.0;
	
	if (curr != null)
		{
		while(curr != null)
			{
			total += curr.getItem().getQuantity() * curr.getItem().getPrice();
			curr = curr.getNext();
			}
		}//for
	else System.out.println("The shopping list is empty. Try adding some items! ");
	
	return total;
	}//getCount


}//KeyedListPorenza