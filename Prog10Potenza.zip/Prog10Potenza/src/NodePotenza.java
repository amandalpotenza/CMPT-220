/**
 * 
 * @author Amanda Potenza <br>
 *
 *This is the class definition for NodePotenza <br>
 *This Node class links items 
 */
public class NodePotenza {
	/**
	 * Instance variable for the item
	 */
	private ItemPotenza myItem;
	/**
	 * Instance variable for the next NodePotenza
	 */
	private NodePotenza myNext;

/**
 * The null/default constructor for NodePotenza	
 */	
public NodePotenza()
	{
	myItem = null;
	myNext = null;
	}//null constructor

/**
 * The full constructor for KeyedListPotenza	
 */	
public NodePotenza(ItemPotenza item)
	{
	myItem = item;
	myNext = null;
	}//full constructor

/**
 * setter for item
 * 
 * @param new item object
 */
public void setItem(ItemPotenza item)
	{
	myItem = item;
	}//setItem

/**
 * setter for next
 * 
 * @param new node for the next node
 */
public void setNext(NodePotenza next)
	{
	myNext = next;
	}//setNext

/**
 * the getter for item
 * 
 * @return current item object
 */
public ItemPotenza getItem()
	{
	return myItem;
	}//getItem

/**
 * the getter for next
 * 
 * @return next node
 */
public NodePotenza getNext()
	{
	return myNext;
	}//getNext

}//NodePotenza
