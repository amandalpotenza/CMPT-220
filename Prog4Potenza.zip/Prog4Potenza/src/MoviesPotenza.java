//Amanda Potenza
//Prog 4
//2/16/23 before 10:30 am
//Purpose: This program is designed to track pay-per-view movies while implementing methods
//
//input: user name, custID, num movies ordered, movie lengths and rating
//output: user name, custID, num movies ordered, cost of movies, service charge, final cost, summary of data (max, min, sum, avg)
//
//Certification of Authenticity: I certify this lab is entirely my own work

import java.util.*;


public class MoviesPotenza 
{
	//declare keyboard for project
	static Scanner keyboard = new Scanner(System.in);
	
	public static void main(String[] args) 
	{

		int custID = 0;
		String userName;
		int moviesOrdered = 0;
		double serviceCharge = 0;
		double costNoServiceOrTax = 0;
		double finalCost = 0;
		int customerCount = 0;
		double highestBill = Integer.MIN_VALUE;
		int highestBillID = 0;
		String highestBillName = "";
		double lowestBill = Integer.MAX_VALUE;
		int lowestBillID = 0;
		String lowestBillName = "";
		double sumOfBills = 0;
		double avgOfBills = 0;
		
		
		System.out.println("Welcome! This program will track the total cost of pay-per-view movies. ");
		System.out.print("Please enter the customer ID or 0 to quit: ");
		custID = keyboard.nextInt();
		
		while (custID != 0)
		{
		
			customerCount ++; //add 1 to customer count
				
			//introduce program and prompt for basic info
			System.out.print("First Name: ");
			userName = keyboard.next();
			System.out.print("Number of movies ordered: ");
			moviesOrdered = keyboard.nextInt();
			
			while (moviesOrdered < 1)
			{
				System.out.print("Invalid input. Try again: ");
				moviesOrdered = keyboard.nextInt();
			}//while -- to validate

			//assign values to the results of each method and output results
			costNoServiceOrTax = chooseMovies(moviesOrdered);
			serviceCharge = calcServiceCharge(moviesOrdered, costNoServiceOrTax);
			finalCost = calcTotalDue(costNoServiceOrTax, serviceCharge);
			
			outputResults(userName, custID, moviesOrdered, costNoServiceOrTax, serviceCharge, finalCost);
			
			
			if (finalCost > highestBill)
			{
			highestBill = finalCost;
			highestBillID = custID;
			highestBillName = userName;
			}//if  - finds the highest bill of all customers
			
			if (finalCost < lowestBill)
			{
			lowestBill = finalCost;
			lowestBillID = custID;
			lowestBillName = userName;
			}//if  - finds the lowest bill of all customers
			
			//add customer's total to overall sum of patients, and find avg. of all inputs
			sumOfBills += finalCost;
			avgOfBills = sumOfBills / customerCount;
			
			
			System.out.println();
			System.out.print("\nTo enter another user, please enter their customer ID here or 0 to quit:");
			custID = keyboard.nextInt();
			
		}//while
		
		
		//if 0 customers are calculated, no data is shown. Otherwise, program displays a summary of the session.
		if (customerCount == 0) 
			System.out.println("You have collected data from 0 customers. No data can be shown. Goodbye. ");
		
		else
		{
			System.out.println();
			System.out.println("Thank you for using this program. Here is a rundown of your data.");
			System.out.println("Number of Patients: " + customerCount);
			System.out.printf("Highest bill was $%.2f " + "paid by the patient ID " + highestBillID + " aka " + highestBillName, (highestBill));
			System.out.printf("\nLowest bill was $%.2f " + "paid by the patient ID " + lowestBillID + " aka " + lowestBillName, (lowestBill));
			System.out.printf("\nTotal sum of all the bills: $%.2f", (sumOfBills));
			System.out.printf("\nAverage bill amount: $%.2f", (avgOfBills));
			System.out.println("\nGoodbye!");
		}//if else
		

		
	keyboard.close();
	}//main
	
	
//chooseMovies will return the total cost of all of the movies chosen by the user
	public static double chooseMovies(int numMovies)
	{
	
		int movieLength = 0;
		String fakeRating;
		char rating;
		double costPerMin = 0;
		double movieCost = 0;
		double totalMovieCost = 0;
		
		for (int i = 0; i < numMovies; i++)	
		{		
			do
			{
				System.out.println("Enter movie #" + (i+1) + " length (1 - 240 minutes): ");
				movieLength = keyboard.nextInt();
				
			}//do
			while ((movieLength < 1)||(movieLength > 240)); 
			
			
			do
			{
				System.out.print("Type 'G' for G-rated, 'P' for PG-rated, 'R' for R-rated, 'X' for X-rated, and 'O' for other: ");
				fakeRating = keyboard.next();
				rating = fakeRating.toUpperCase().charAt(0);
			}//do
			while ((rating != 'G')&&(rating != 'P')&&(rating != 'R')&&(rating != 'X')&&(rating != 'O'));
			
			
			
			switch (rating)
			{
			case 'G':
				costPerMin = 0.048;
				break;
			case 'P':
				costPerMin = 0.062;
				break;
			case 'R':
				costPerMin = 0.073;
				break;
			case 'X':
				costPerMin = 0.273;
				break;
			case 'O':
				costPerMin = 0.05;
				break;
			}//switch
		
			movieCost = movieLength * costPerMin;
			totalMovieCost += movieCost;
			
		}//for	
		return totalMovieCost;
	}//chooseMovies


//calcServiceCharge will calculate service change based on total cost and num of movies
public static double calcServiceCharge(int numMovies, double totalCost)
	
	{
	double serviceChargePercent = 0;
	double serviceCharge = 0;

	if ((numMovies > 0)&&(numMovies <= 3))
		serviceChargePercent = .15;
	else if (numMovies <= 7)
		serviceChargePercent = .12;
	else if (numMovies <= 11)
		serviceChargePercent = .09;
	else
		serviceChargePercent = .06;
	
	serviceCharge = totalCost * serviceChargePercent;
	return serviceCharge;
	
	}//calcServiceCharge


//calcTotalDue adds the movie cost and service charge
public static double calcTotalDue(double movieCost, double serviceCharge)
	{
	double totalAmt = 0;
	double tax = 1.08;
	
	totalAmt = (tax * (movieCost + serviceCharge));
	return totalAmt;
	}//calcTotalDue

//outputResults prints the data
public static void outputResults(String name, int customerID, int numMovies, double movieCost, double serviceCharge, double totalCost)
	{
		System.out.println("First Name: " + name);
		System.out.println("Customer ID: " + customerID);		
		System.out.println("Number of movies purchased: " + numMovies);
		System.out.printf("Cost of movies: $%.2f", (movieCost));
		System.out.printf("\nService Charge: $%.2f", (serviceCharge));
		System.out.printf("\nTotal cost: $%.2f", (totalCost));
	}//outputResults

}//MoviesPotenza
