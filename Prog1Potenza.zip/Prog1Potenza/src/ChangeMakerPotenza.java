//Amanda Potenza
//Prog 1
//11/26/23 before 10:45 am
//Purpose: Program calculates smallest amount of dollars and coins users can use for a given amount of change
//
//input: change 
//output:  that change in coins and bills, along with how many coins and bills were used
//
//Certification of Authenticity:I certify this lab is entirely my own work

import java.util.*;

public class ChangeMakerPotenza 
{

	//declare keyboard for project
	static Scanner keyboard = new Scanner(System.in);
	
	
	public static void main(String[] args) 
	{
		//declare and initialize variables (now including bills!)
		int amount = 0;
		int originalAmount = 0;
		int twentyBill = 0;
		int tenBill = 0;
		int fiveBill = 0;
		int oneBill = 0;
		int quarters = 0;
		int dimes = 0;
		int nickels = 0;
		int pennies = 0;
		int totalBills = 0;
		int totalChange = 0;
		
		//greet the user and describe the program
		System.out.println("Welcome to the Change Maker System!");
		System.out.println("Enter a whole number");
		System.out.println("I will output a combination of dollars and coins");
		System.out.println("that equals that amount of change.");
		
		//Get the input
		System.out.print("\nEnter amount to be changed: ");
		amount = keyboard.nextInt();
		
		//calculate dollars
		originalAmount = amount;
		twentyBill = amount / 2000;
		amount = amount % 2000;
		tenBill = amount / 1000;
		amount = amount % 1000;
		fiveBill = amount / 500;
		amount = amount % 500;
		oneBill = amount / 100;
		amount = amount % 100;
		//calculate change
		quarters = amount / 25;
		amount = amount % 25;
		dimes = amount / 10;
		amount = amount % 10;
		nickels = amount / 5;
		amount = amount % 5;
		pennies = amount;
		
		//calculate total number of bills and coins
		totalBills = twentyBill + tenBill + fiveBill + oneBill;
		totalChange = quarters + dimes + nickels + pennies;
		
		//ouput the results
		System.out.println(originalAmount + " cents in coins can be given as");
		System.out.println(twentyBill + " twenty dollar bills");
		System.out.println(tenBill + " ten dollar bills");
		System.out.println(fiveBill + " five dollar bills");
		System.out.println(oneBill + " one dollar bills");
		System.out.println(quarters + " quarters");
		System.out.println(dimes + " dimes");
		System.out.println(nickels + " nickels");
		System.out.println(pennies + " pennies");
		System.out.println("In total, you used " + totalBills + " bills, and " + totalChange + " coins.");
		
		System.out.println("\nThanks! Goodbye.");
	}//main
}//Changemaker
