//Amanda Potenza
//Prog 6
//3/2/23 before 10:30 am
//Purpose: Use classes to analyze and draw rectangles
//
//Certification of Authenticity: I worked on this code with Luke Jacobs from the academic learning center and enharmonics

public class RectanglePotenza 
{
private int myWidth;
private int myHeight;
private char myFillStyle;


public RectanglePotenza(int width, int height, char fillStyle)
	{
	myWidth = width;
	myHeight = height;
	myFillStyle = fillStyle;
	}//full constructor

public RectanglePotenza()
	{
	myWidth = 10;
	myHeight = 5;
	myFillStyle = '*';
	}//null constructor
	
	
//declare getters and setters
public void setWidth(int width)
	{
	myWidth = width;
	}//set width
public void setHeight(int height)
	{
	myHeight = height;
	}//set height
public void setFillStyle(char fillStyle)
	{
	myFillStyle = fillStyle;
	}//set fill style
public int getWidth()
	{
	return myWidth;
	}//get width
public int getHeight()
	{
	return myHeight;
	}//get height
public char getFillStyle()
	{
	return myFillStyle;
	}//get fill style


//find area of rectangle
public double rectangleArea()
	{
	double area = 0;
	
	area = myWidth * myHeight;

	return area;
	}//rectangleArea

//find perimeter of rectangle
public double rectanglePerimeter()
	{
	double perimeter = 0;
	
	perimeter = ((2 * myWidth) + (2 * myHeight));

	return perimeter;
	}//rectanglePerimeter


//draw rectangle
public void drawRectangle()
	{
	int x = 0;
	int y = 0;
	

	if ((myWidth == 0)||(myHeight == 0))
		System.out.println("Cannot print. Make sure you have defined both your width and height as positive ints.");
		
	else
		{
		System.out.println();
		for (x = 0; x < myHeight; x++)
			{
			for (y = 0; y < myWidth; y++)
				System.out.print(myFillStyle);
			System.out.println();
			}//for 
		}//else
	
	}//draw rectangle


//draw outline
public void drawOutline()
	{
	int x = 0;
	int y = 0;
	
		
	if ((myWidth == 0)||(myHeight == 0))
		System.out.println("Cannot print. Make sure you have defined both your width and height as positive ints.");
		
	else
		{
		System.out.println();
		for (x = 0; x < myWidth; x++)
			System.out.print(myFillStyle);
		System.out.println();
		for (x = 1; x < (myHeight - 1); x++)
			{
			System.out.print(myFillStyle);
			for (y = 0; y < (myWidth - 2); y++)
				System.out.print(" ");
			System.out.print(myFillStyle);
			System.out.println();
			}//for
		for (x = 0; x < myWidth; x++)
			System.out.print(myFillStyle);
		System.out.println();
		}//else
	

	}//draw outline


//prints answer
public String ToString()
	{
	String ans = "Width: " + myWidth + "\n";
	ans += "Height: " + myHeight + "\n";
	ans += "Fill Type: " + myFillStyle + "\n";
	ans += "Area: " + rectangleArea() + "\n";
	ans += "Perimeter: " + rectanglePerimeter() + "\n";
	return ans;
	}//ToString

}//RectanglePotenza
