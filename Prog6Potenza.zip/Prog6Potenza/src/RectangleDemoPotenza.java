//Amanda Potenza
//Prog 6
//3/2/23 before 10:30 am
//Purpose: Use classes to analyze and draw rectangles
//
//input: a char, and width, height, and fill style
//output: width, height, fill style, area, perimeter, text description, rectangle drawn, and/or rectangle outline
//
//Certification of Authenticity: I worked on this code with Luke Jacobs from the academic learning center and enharmonics

import java.util.Scanner;

public class RectangleDemoPotenza 
{
	//declare keyboard for project
		static Scanner keyboard = new Scanner(System.in);
		
	public static void main(String[] args) 
	{
		
		//initialize variables
		RectanglePotenza rec1 = new RectanglePotenza();
		String fakeChoice = "";
		char choice;
		int width = 0;
		int height = 0;
		String fakeFillStyle = " ";
		char fillStyle = ' ';
				
		
		//introduce program
				System.out.println("Welcome! This program will draw and analyze rectangles. Enter one of the options below to begin.");

				
				//menu
				do
				{
					System.out.println();
					System.out.println("W : Assign the Width");
					System.out.println("H : Assign the Height");
					System.out.println("F : Assign the Fill Style");
					System.out.println("A : Calculate the Area");
					System.out.println("P : Calculate the Perimeter");
					System.out.println("T : Text Description of the Rectangle");
					System.out.println("D : Draw the Rectangle");
					System.out.println("O : Draw the Outline of the Rectangle");
					System.out.println("Q : Quit");
				
					System.out.print("Enter choice: ");
					fakeChoice = keyboard.next();
					choice = fakeChoice.toUpperCase().charAt(0);
					
					
					switch (choice)
					{
					case 'W':
						// Allows the user to set the width
						System.out.print("Set width: ");
						width = keyboard.nextInt();
						while (width <= 0)
							{
							System.out.println("Invalid. Try again.");
							System.out.print("Set width: ");
							width = keyboard.nextInt();
							}//while
						rec1.setWidth(width);
						break;
					case 'H':
						//Allows the user to set the height
						System.out.print("Set height: ");
						height = keyboard.nextInt();
						while (height <= 0)
							{
							System.out.println("Invalid. Try again.");
							System.out.print("Set height: ");
							height = keyboard.nextInt();
							}//while
						rec1.setHeight(height);
						break;
					case 'F':
						//Allows the user to set the fill style
						System.out.print("Set fill style: ");
						fakeFillStyle = keyboard.next();
						fillStyle = fakeFillStyle.charAt(0);
						rec1.setFillStyle(fillStyle);
						break;
					case 'A':
						//Calculates area
						System.out.println("Area is: " + rec1.rectangleArea());
						break;
					case 'P':
						//Calculates perimeter
						System.out.println("Perimeter is: " + rec1.rectanglePerimeter());
						break;
					case 'T':
						//Prints text description
						System.out.println(rec1.ToString());
						break;
					case 'D':
						//Prints a drawing of the rectangle
						rec1.drawRectangle();
						break;
					case 'O':
						//Prints outline of the rectangle
						rec1.drawOutline();
						break;
					case 'Q':
						//Quit
						System.out.println("Thank you for using this program. Goodbye!");
						break;
					default:
						//Validation
						System.out.println("Invalid. Try again");
						break;
					}//switch
				}//do
				while ((choice != 'Q')); 
				
				
	keyboard.close();
	}//main 
	

}//RectangleDemoPotenza
