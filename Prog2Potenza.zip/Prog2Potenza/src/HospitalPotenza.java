//Amanda Potenza
//Prog 2
//2/2/23 before 10:45 am
//Purpose: This program is designed to automate the processing of insurance payments
//
//input: Patient ID, Household income, Insurance plan, Number of days
//output:  Patient ID, Household income, Insurance plan, Number of days, 
//         Admittance fee, Per Diem rate, Service fee, Discount, and Total bill
//
//Certification of Authenticity: I certify this lab is entirely my own work

import java.util.*;

public class HospitalPotenza 
{

	//declare keyboard for project
	static Scanner keyboard = new Scanner(System.in);
	
	
	public static void main(String[] args) 
	{//main
		
		//declare and initialize variables 
		int patientID = 0;
		double income = 0;
		char insurancePlan;
		String insurancePlanFull = "";
		int days = 0;
		int admittanceFee = 250;
		double serviceFee = 0;
		double discount = 0;
		double totalBill = 0;
		
		//Introduce the program and ask user to input basic information 
		System.out.println("Welcome! This program will help you to more simply calculate insurance payments.");
		System.out.print("Please enter the patient ID: ");
		patientID = keyboard.nextInt();
		System.out.print("Now please enter the patient's household income: ");
		income = keyboard.nextDouble();
		System.out.println("Please specify the patient's insurance plan.");
		System.out.print("Type 'B' for Blue Plus, 'M' for Medhealth, 'H' for Health Plan, and 'N' for no insurance: ");
		insurancePlan = keyboard.next().charAt(0);
		System.out.print("Please type the number of days that the patient was in the hospital for: ");
		days = keyboard.nextInt();
		
		
		//determine service fee (Per Diem rate) based on insurance plan 
		switch (insurancePlan)
		{
		case 'b':
		case 'B':
			if (income < 14000)
				serviceFee = 40 * days;
			else if (income <= 67500)
				serviceFee = 75 * days;
			else
				serviceFee = 150 * days;
			insurancePlanFull = "Blue Plus";
			break;
		case 'm':
		case 'M':
			if (income < 20000)
				serviceFee = 75 * days;
			else if (income <= 50000)
				serviceFee = 100 * days;
			else
				serviceFee = 120 * days;
			insurancePlanFull = "Med-Health";
			break;
		case 'h':
		case 'H':
			if (income < 12500)
				serviceFee = 65 * days;
			else if (income <= 63000)
				serviceFee = 80 * days;
			else
				serviceFee = 150 * days;
			insurancePlanFull = "Health Plan";
			break;
		case 'n':
		case 'N':
				serviceFee = 500 * days;
				insurancePlanFull = "N/A";
			break;
					
		}
		
		
		//determine cost by adding admittance fee ($250) and service fee, then subtract the discount for long term patients 
		if (days <= 25)
			totalBill = admittanceFee + serviceFee;
		else
		{
			discount = days/7 * 450; //determine discount for longterm patients
			totalBill = admittanceFee + serviceFee - discount;
		}
			
		System.out.println();
		System.out.println("Here are your results.");
		System.out.println("Patient ID: " + patientID);
		System.out.printf("Household Income: $%.2f", income);
		System.out.println("\nInsurance Plan: " + insurancePlanFull);
		System.out.println("Number of Days: " + days);
		System.out.println("Admittance Fee: $" + admittanceFee);
		System.out.printf("Per Diem Rate: $%.2f", (serviceFee / days));
		System.out.printf("\nService Fee: $%.2f", serviceFee);
		System.out.printf("\nDiscount: $%.2f", discount);
		System.out.printf("\nTotal Bill: $%.2f", totalBill);

		System.out.println("\nThank you for using this program. Goodbye!");
	}//main
}//Changemaker
