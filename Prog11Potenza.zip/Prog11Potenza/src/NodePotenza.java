/**
 * 
 * @author Amanda Potenza <br>
 *
 *This is the class definition for NodePotenza <br>
 *This Node class links cards 
 */
public class NodePotenza {
	/**
	 * Instance variable for the card
	 */
	private CardPotenza myCard;
	/**
	 * Instance variable for the next NodePotenza
	 */
	private NodePotenza myNext;

/**
 * The null/default constructor for NodePotenza	
 */	
public NodePotenza()
	{
	myCard = null;
	myNext = null;
	}//null constructor

/**
 * The full constructor for KeyedListPotenza	
 */	
public NodePotenza(CardPotenza card)
	{
	myCard = card;
	myNext = null;
	}//full constructor

/**
 * setter for card
 * 
 * @param new card object
 */
public void setCard(CardPotenza card)
	{
	myCard = card;
	}//setCard

/**
 * setter for next
 * 
 * @param new node for the next node
 */
public void setNext(NodePotenza next)
	{
	myNext = next;
	}//setNext

/**
 * the getter for card
 * 
 * @return current card object
 */
public CardPotenza getCard()
	{
	return myCard;
	}//getCard

/**
 * the getter for next
 * 
 * @return next node
 */
public NodePotenza getNext()
	{
	return myNext;
	}//getNext

}//NodePotenza
