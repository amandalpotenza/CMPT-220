
public class StackPotenza {
	/**
	 * Instance variable for the top of linked list
	 */
	private NodePotenza myTop;
	
/**
 * The null/default constructor for NodePotenza	
 */	
public StackPotenza()
	{
	myTop = null;
	}//null constructor

/**
 * tells whether or not stack is empty
 * 
 * @return boolean telling if the stack; is empty or not
 */
public boolean isEmpty()
	{
	return(myTop == null);
	}//isEmpty
	
/**
 * tells whether or not stack is full
 * 
 * @return boolean telling if the list is full
 */
public boolean isFull()
	{
	boolean ans = false;
	int count = 0;
	NodePotenza curr = myTop;
	NodePotenza prev = null;
	
	while(curr != null)
		{
		prev = curr;
		curr = curr.getNext();
		count++;
		}//while
	
	//max per stack = 26 because 52/2. I believe this should work because the only time we could use "isFull" method is when we deal
	if (count >= 26)
		ans = true;
	
	return ans;
	}//isFull 

/**
 * adds card object to the stack
 * 
 * @param card from input file
 * @return boolean telling card was added or not
 */
public boolean push(CardPotenza card)
	{
	boolean ans = false;
	NodePotenza newCard = null;
	
	if(!isFull())
		{
		ans = true;
		newCard = new NodePotenza();
		newCard.setNext(myTop);
		newCard.setCard(card);
		myTop = newCard;
		}//if
	
	return ans;
	}//push

/**
 * removes card object to the stack
 * 
 * @return the card object that was removed
 */
public CardPotenza pop()
	{
	CardPotenza ans = null;
	
	if(!isEmpty())
		{
		ans = myTop.getCard();
		myTop = myTop.getNext();
		}//if
	
	return ans;
	}//pop
	
}//StackPotenza
