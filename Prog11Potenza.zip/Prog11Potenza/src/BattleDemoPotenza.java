/**
 * @author Amanda Potenza <br>
 * 
 * Prog 11 <br>
 * Due Date and Time: 4/17/23 before 10:30am <br>
 * 
 * Purpose: This program stores objects in a linked list . We will use file input to add songs initially. You can interact with this list using different methods in the classes.
 * 
 * Input: File name, Menu option, Item name, quantity, price <br>
 * 
 * Output: description of all items, specific item description, total count, total cost, whether list is empty or full, feedback for each option <br>
 * 
 * Certification of Authenticity: <br>
 * 	I certify this lab is entirely my own work. <br>
 */


//Use import to gain access to Java utility classes for file input/output.
import java.io.*;
import java.util.*;

public class BattleDemoPotenza {
	
	//declare keyboard for project
	static Scanner keyboard = new Scanner(System.in);
		
	public static void main(String[] args) 
		{

		//initialize variables
		StackPotenza deck1 = new StackPotenza();
		StackPotenza deck2 = new StackPotenza();
		StackPotenza discard1 = new StackPotenza();
		StackPotenza discard2 = new StackPotenza();
		int rounds = 0;
		String winningPlayer = "no one";
		int player1count = 0;
		int player2count = 0;
		
		
		System.out.println("Welcome to this battle program! ");
		//deal the cards
		deal(deck1, deck2);
		
		//find num cards in deck
		int count = countCards(deck1) + countCards(deck2);
		
		//play rounds
		while((rounds < 1000)&&(winningPlayer.equals("no one")))
			{
			play(deck1, deck2, discard1, discard2);
			winningPlayer = isWinner(deck1, deck2, discard1, discard2);
			rounds++;
			}//while
		
		//caculate num cards per player and decide winner (in case 1000 rounds were played)
		player1count = countCards(deck1) + countCards(discard1);
		player2count = countCards(deck2) + countCards(discard2);
		if (player1count > player2count)
			winningPlayer = "Player 1";
		if (player2count > player1count)
			winningPlayer = "Player 2";
		
		if (count == 0)
			System.out.println("There are no cards in this deck. No data can be shown.");
		else
			printResults(count, rounds, player1count, player2count, winningPlayer);
		
		}//main
	
/**
 * deal splits the cards in the input file evenly between the 2 players  
 * 
 * @param cards1 player 1's stack of cards
 * @param cards2 player 2's stack of cards
 */
public static void deal(StackPotenza cards1, StackPotenza cards2)
	{
	//initialize variables
	CardPotenza newCard = null;
	int value = 0;
	String suit = "none";
	int numItems = 0;
	String filename = null;
	int i = 0;
	
	System.out.print("Enter the name of your initial input file:  ");
    filename = keyboard.next(); 
    
	//create the reference to the file, declared up here because of the "catch"
    File inputFile = new File(filename);
	
	try 
		{
		//Create a second Scanner object, this one for reading from the file
	    Scanner input = new Scanner(inputFile);
		
	    numItems = input.nextInt();
	    
	    if (numItems <= 52)
		    {
		    for (i = 0; i < numItems; i++)
		    	{
				do 
					{
					value = input.nextInt();
					}//do
				while ((value < 2)||(value > 14));
				do
					{
					suit = input.next().toUpperCase();
					}//do
				while (!((suit.equals("SPADES"))||(suit.equals("DIAMONDS"))||(suit.equals("HEARTS"))||(suit.equals("CLUBS"))));
		
				
				//create new  object and print if it was added or not
				newCard = new CardPotenza(value, suit);
				if(i % 2 == 0)
					cards1.push(newCard);
				if(i % 2 == 1)
					cards2.push(newCard);
		    	}//for
		    }//if
	    else System.out.println("Error adding items. Limit has already been reached. Try editing your file document.");
		
		////close input Scanner
	      input.close();
		}//try
	
	catch(FileNotFoundException ex)
	    {
	      System.out.println("Failed to find file: " + inputFile.getAbsolutePath()); 
	      System.out.println("Try rerunning the program or entering the songs manually below.");
	    }//catch
    catch(InputMismatchException ex)
	    {
	    System.out.println("Type mismatch for the number I just tried to read.");
	    System.out.println(ex.getMessage());
	    }
    catch(NumberFormatException ex)
	    {
	    System.out.println("Failed to convert String text into an integer value.");
	    System.out.println(ex.getMessage());
	    }//catch
    catch(NullPointerException ex)
	    {
	    System.out.println("Null pointer exception.");
	    System.out.println(ex.getMessage());
	    }//catch
	catch(Exception ex)
	    {
	    System.out.println("Something went wrong");
	    ex.printStackTrace();
	    }//catch
	
	}//fileOptionAdd
	
/**
 * Follows the rules of "battle" to pop and push cards to appropriate stacks
 * 
 * @param cards1
 * @param cards2
 * @param discardCards1
 * @param discardCards2
 */
public static void play(StackPotenza cards1, StackPotenza cards2, StackPotenza discardCards1, StackPotenza discardCards2)
	{
	CardPotenza playCard1 = null;
	CardPotenza playCard2 = null;


	//make sure there are cards in the stack
	if((cards1.isEmpty())||(cards2.isEmpty()))
		{
		if (cards1.isEmpty())
			copy(discardCards1, cards1);
		if (cards2.isEmpty())
			copy(discardCards2, cards2);
		}//if
	
	//if there are cards, play the game
	if(!((cards1.isEmpty())||(cards2.isEmpty())))
		{
		playCard1 = cards1.pop();
		playCard2 = cards2.pop();
		
		if (playCard1.getValue() > playCard2.getValue())
			{
			discardCards1.push(playCard1);
			discardCards1.push(playCard2);
			}//if
		else if (playCard2.getValue() > playCard1.getValue())
			{
			discardCards2.push(playCard2);
			discardCards2.push(playCard1);
			}//if
		else
			{
			discardCards1.push(playCard1);
			discardCards2.push(playCard2);
			}//else
		}//if
	}//play
 
/**
 * copy pushes cards from one stack to another
 * 
 * @param first
 * @param second
 */
public static void copy(StackPotenza first,StackPotenza second)
	{
	StackPotenza temp = new StackPotenza();

	while(!(first.isEmpty()))
		temp.push(first.pop());
	while(!(temp.isEmpty()))
		second.push(temp.pop());
	}//copy

/**
 * countCards counts the number of cards in a stack
 * 
 * @param stack
 * @return
 */
public static int countCards(StackPotenza stack)
	{
	StackPotenza temp = new StackPotenza();
	int count = 0;
	
	while(!(stack.isEmpty()))
		{
		temp.push(stack.pop());
		count++;
		}//while
	while(!(temp.isEmpty()))
		stack.push(temp.pop());
	
	return count;
	}//getCount

/**
 * determines if there is a winner (until 1000 rounds are played)
 * 
 * @param cards1
 * @param cards2
 * @param discardCards1
 * @param discardCards2
 * @return
 */
public static String isWinner(StackPotenza cards1, StackPotenza cards2, StackPotenza discardCards1, StackPotenza discardCards2)
	{
	String winner = "no one";
	
	if ((cards1.isEmpty()) && (discardCards1.isEmpty()))
		winner = "Player 2";
	if ((cards2.isEmpty()) && (discardCards2.isEmpty()))
		winner = "Player 1";
	
	return winner;
	}//isWinner

/**
 * prints a game summary
 * 
 * @param numCards
 * @param numPlays
 * @param player1num
 * @param player2num
 * @param winner
 */
public static void printResults(int numCards, int numPlays, int player1num, int player2num, String winner)
	{
	System.out.println("========================");
	System.out.println("Battle Card Game Summary");
	System.out.println("========================");
	System.out.println("The game started with " + numCards + " cards.");
	System.out.println("There were " + numPlays + " plays in the game.");
	if (winner.equals("no one"))
		System.out.println("The game did not end with a clear winner.");
	else
		System.out.println("The game ended with a clear winner.");
	System.out.println("Player 1 ended up with " + player1num + " cards.");
	System.out.println("Player 2 ended up with " + player2num + " cards.");
	System.out.println("The winner was " + winner + ".");

	}//printResults

}//BattleDemoPotenza
