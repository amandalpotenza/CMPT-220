/**
 * 
 * @author Amanda Potenza <br>
 *
 *This is the class definition for CardPotenza <br>
 *This class creates cards 
 */
public class CardPotenza {
	
	private int myCardValue;
	private String mySuit;

	
/**
 * the null/default constructor for CardPotenza
 */
public CardPotenza()
	{
	myCardValue = 0;
	mySuit = "None";
	}//null constructor


/**
 * Full constructor for CardPotenza
 * 
 * @param quantity	New quantity for item
 * @param price	New unit price for item
 */
public CardPotenza(int value, String suit)
	{
	myCardValue = value;
	mySuit = suit;
	}//full constructor


/**
 * setter for card value
 * 
 * @param name	new value for the card
 */
public void setValue(int value)
	{
	myCardValue = value;
	}//setName

/**
 * setter for card suit
 * 
 * @param quantity	new suit for the card
 */
public void setSuit(String suit)
	{
	mySuit = suit;
	}//setQuantity

/**
 * getter for card value
 * 
 * @return current value for the card
 */
public int getValue()
	{
	return myCardValue;
	}//getName

/**getter for suit
 * 
 * @return current suit for card
 */
public String getSuit()
	{
	return mySuit;
	}//getQuantity

/**
 * The toString method for CardPotenza
 * 
 * @return	a String describing the item's instance variables
 */
public String toString()
	{
	String ans = "Value: " + myCardValue + "\n";
	ans+= "Suit: " + mySuit + "\n";
	
	return ans;
	}//toString
}//CardPotenza
