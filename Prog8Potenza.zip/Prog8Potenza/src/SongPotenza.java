
/**
 * 
 * @author Amanda Potenza <br>
 *
 *This is the class definiton for SongPotenza <br>
 *this song class allows users to create a song object with a name, artist, runtime, and price
 */
public class SongPotenza {

	/**
	 * instance varibale for song's name
	 */
	private String myName;
	/**
	 * instance variable for song's artist
	 */
	private String myArtist;
	/**
	 * instance variable for song's runtime
	 */
	private int myRuntime;
	/**
	 * instance variable for song's price
	 */
	private double myPrice;
	
/**
 * full constructor for SongPotenza
 * 
 * @param name	new name for the song
 * @param artist	new artist for the song
 * @param runtime	new runtime for the song
 * @param price	new price for the song
 */
public SongPotenza(String name, String artist, int runtime, double price)
	{
	myName = name;
	myArtist = artist;
	myRuntime = runtime;
	myPrice = price;
	}//full constructor


/**
 * the null/default constructor for SongPotenza
 */
public SongPotenza()
	{
	myName = "none";
	myArtist = "none";
	myRuntime = 0;
	myPrice = 0.0;
	}//null constructor


/**
 * setter for song name
 * 
 * @param name	new name for the song
 */
public void setName(String name)
	{
	myName = name;
	}//setName

/**
 * setter for song artist 
 * 
 * @param artist	new artist for song
 */
public void setArtist(String artist)
	{
	myArtist = artist;
	}//setArtist

/**
 * setter for song runtime
 * 
 * @param runtime	new runtime for song
 */
public void setRuntime(int runtime)
	{
	myRuntime = runtime;
	}//setRuntime

/**
 * setter for song price
 * 
 * @param price	new price for song
 */
public void setPrice(double price)
	{
	myPrice = price;
	}//setPrice

/**
 * getter for song name
 * 
 * @return	current value for name
 */
public String getName()
	{
	return myName;
	}//getName

/**
 * getter for song artist
 * 
 * @return	current value for artist
 */
public String getArtist()
	{
	return myArtist;
	}//getName

/**
 * getter for song runtime
 * 
 * @return current value for runtime
 */
public int getRuntime()
	{
	return myRuntime;
	}//getName

/**
 * getter for song price
 * 
 * @return current value for price
 */
public double getPrice()
	{
	return myPrice;
	}//getName


/**
 * The toString method for SongPotenza
 * 
 * @return	a String describing the song's instance variables
 */
public String toString()
	{
	String ans = "Name: " + myName + "\n";
	ans += "Artist: " + myArtist + "\n";
	ans += "Runtime: " + myRuntime + "\n";
	ans += "Price: $" + String.format("%.2f", myPrice) + "\n"; //had to research this
	
	return ans;
	}//toString
	
}//SongPotenza
