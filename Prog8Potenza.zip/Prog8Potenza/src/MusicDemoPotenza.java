/**
 * @author Amanda Potenza <br>
 * 
 * Prog 8 <br>
 * Due Date and Time: 3/30/23 before 10:30am <br>
 * 
 * Purpose: This program stores song objects in a playlist array. We will use file input to add songs initially. You can interact with this playlist using different methods in the classes.
 * 
 * Input: File name, Menu option, Song name, artist, runtime, price <br>
 * 
 * Output: Longest song object, shortest song object, number of songs, total cost, description of all songs <br>
 * 
 * Certification of Authenticity: <br>
 * 	I certify this lab is entirely my own work. <br>
 */

//Use import to gain access to Java utility classes for file input/output.
import java.io.*;
import java.util.*;


public class MusicDemoPotenza 
{

	//declare keyboard for project
			static Scanner keyboard = new Scanner(System.in);
			
	public static void main(String[] args) {
		
		//initialize variables
		String fakeChoice = "";
		char choice;
	    PlaylistPotenza playlist = new PlaylistPotenza();
		
		System.out.println("Welcome to this playlist program! ");
		fileAddSongs(playlist);
	    
		// create a menu
		do
			{
			System.out.println();
			System.out.println("--------------------------");
			System.out.println();
			
			System.out.println();
			System.out.println("A - Add song to playlist ");
			System.out.println("L - Find the longest song in the playlist");
			System.out.println("S - Find the shortest song in the playlist ");
			System.out.println("N - Find the number of songs in the playlist ");
			System.out.println("T - Find the total cost of all the songs in the playlist");
			System.out.println("P - Print out the details of all the songs in the playlist");
			System.out.println("Q - Quit");
			System.out.println();
			System.out.println("Enter here:");
			fakeChoice = keyboard.next();
			choice = fakeChoice.toUpperCase().charAt(0);
			
			switch (choice)
			{
			case 'A':
				optionAddSong(playlist);
				break;
			case 'L':
				if (playlist.findLongest() != null)
					System.out.println("The following is the longest song: \n"+ playlist.findLongest().toString()); 
				else System.out.println("The playlist is empty. Try adding a song.");
				break;
			case 'S':
				if (playlist.findShortest() != null)
					System.out.println("The following is the shortest song: \n"+ playlist.findShortest().toString()); 
				else System.out.println("The playlist is empty. Try adding a song.");
				break;
			case 'N':
				System.out.println("There are " + playlist.getSize() + " songs in the playlist.");
				break;
			case 'T':
				System.out.printf("The total cost of all the songs is: $%.2f", playlist.calcTotalCost());
				if (playlist.calcTotalCost() == 0.0)
					System.out.println(" There are no songs in your playlist.");
				System.out.println();
				break;
			case 'P':
				playlist.printFullPlaylist();
				break;
			case 'Q':
				System.out.println();
				System.out.println("Thank you for using this program! Goodbye.");
				break;
			default:
			}//switch
		}//do
		while (choice != 'Q');
		
		
	     keyboard.close();
	}//main

	
/**
 * optionAddSong calls the addToPlaylist method and validates the input before successfully adding the new song to the playlist array  
 * @param listOfSongs		listOfSongs is our playlist array where the song will be added
 */
public static void optionAddSong(PlaylistPotenza listOfSongs)
	{
	//initialize variables
	SongPotenza newSong = null;
	String name = "none";
	String artist = "none";
	int runtime = 0;
	double price = 0.0;
	boolean ok = false;
	
	
	//prompt user to input song variables and validate them
	System.out.println("Enter name of song: ");
	name = keyboard.next();
	System.out.println("Enter artist of song: ");
	artist = keyboard.next(); 
	
	do 
		{
		System.out.println("Enter runtime of song in seconds: ");
		runtime = keyboard.nextInt();
		}//do
	while (runtime <= 0);
	
	do
		{
		System.out.println("Enter price of song: ");
		System.out.print("$");
		price = keyboard.nextDouble();
		}//do
	while (price <= 0);

	
	//create new song object and print if it was added or not
	newSong = new SongPotenza(name, artist, runtime, price);
	ok = listOfSongs.addToPlaylist(newSong);
	
	if (ok == true)
		 System.out.println("The song has been added!");
	else System.out.println("Error adding song. Limit has already been reached.");
	}//optionAddSong


/**
 * fileAddSongs reads a .txt file to inputs songs using addToPlaylist
 * @param listOfSongs	listOfSongs is our playlist array where the song will be added
 */
public static void fileAddSongs(PlaylistPotenza listOfSongs)
	{
	//initialize variables
	SongPotenza newSong = null;
	String name = "none";
	String artist = "none";
	int runtime = 0;
	double price = 0.0;
	int numSongs = 0;
	String filename = null;
	int i = 0;
	
	System.out.print("Enter the name of your initial input file:  ");
    filename = keyboard.next();    
    
	//create the reference to the file, declared up here because of the "catch"
    File inputFile = new File(filename);
	
	try 
		{
		//Create a second Scanner object, this one for reading from the file
	    Scanner input = new Scanner(inputFile);
		
	    numSongs = input.nextInt();
	    
	    if (numSongs <= 10)
		    {
		    for (i = 0; i < numSongs; i++)
		    	{
				name = input.next();
				artist = input.next(); 
				do 
					{
					runtime = input.nextInt();
					}//do
				while (runtime <= 0);
				do
					{
					price = input.nextDouble();
					}//do
				while (price <= 0);
		
				
				//create new song object and print if it was added or not
				newSong = new SongPotenza(name, artist, runtime, price);
				listOfSongs.addToPlaylist(newSong);
		    	}//for
		    }//if
	    else System.out.println("Error adding songs. Limit has already been reached. Try editing your file document.");
		
		////close input Scanner
	      input.close();
		}//try
	
	catch(FileNotFoundException ex)
	    {
	      System.out.println("Failed to find file: " + inputFile.getAbsolutePath()); 
	      System.out.println("Try rerunning the program or entering the songs manually below.");
	    }//catch
    catch(InputMismatchException ex)
	    {
	    System.out.println("Type mismatch for the number I just tried to read.");
	    System.out.println(ex.getMessage());
	    }
    catch(NumberFormatException ex)
	    {
	    System.out.println("Failed to convert String text into an integer value.");
	    System.out.println(ex.getMessage());
	    }//catch
    catch(NullPointerException ex)
	    {
	    System.out.println("Null pointer exception.");
	    System.out.println(ex.getMessage());
	    }//catch
	catch(Exception ex)
	    {
	    System.out.println("Something went wrong");
	    ex.printStackTrace();
	    }//catch
	
	}//fileOptionAddSong

}//MusicDemoPotenza




