/**
 * 
 * @author Amanda Potenza <br>
 *
 *This is the class definition for PlaylistPotenza <br>
 *This playlist class holds and stores song objects
 */
public class PlaylistPotenza {

	/**
	 * Instance variable for the playlist's array
	 */
	private SongPotenza [] mySongs;
	/**
	 * Instance variable for the playlist's size
	 */
	private int mySize;
	
	
/**
 * The null/default constructor for playlist	
 */
public PlaylistPotenza()
	{
	int i = 0;
	mySongs = new SongPotenza[10];
	for (i = 0; i < mySize; i++)
		mySongs[i] = null;	
	mySize = 0;
	}//PlaylistPotenza


/**
 * the getter for playlist's size
 * 
 * @return current value of playlist's size
 */
public int getSize()
	{
	return mySize;
	}//getMySize


/**
 * Adds song object to playlist array
 * 
 * @param newSong 	the new song object we want to add
 * @return	boolean decribing whether the song was added or not
 */
public boolean addToPlaylist(SongPotenza newSong)
	{
	boolean success = false;
	if (mySize < mySongs.length)
		{
		mySongs[mySize] = newSong;
		mySize++;
		success = true;
		}//if
	
	return success;
	}//addToPlaylist


/**
 * finds the longest song object in the playlist
 * 
 * @return 	song object with longest runtime
 */
public SongPotenza findLongest()
	{
	int i = 0;
	SongPotenza longest = null;
	int max = Integer.MIN_VALUE;
	
	for (i = 0; i < mySize; i++)
		{
		if (mySongs[i].getRuntime() > max)
			{
			longest = mySongs[i];
			max = longest.getRuntime();
			}//if
		}//for
		
	return longest;
	}//findLongest


/**
 * finds the shortest song object in the playlist
 * 
 * @return song object with the shortest runtime
 */
public SongPotenza findShortest()
	{
	int i = 0;
	SongPotenza shortest = null;
	int min = Integer.MAX_VALUE;
	
	for (i = 0; i < mySize; i++)
		{
		if (mySongs[i].getRuntime() < min)
			{
			shortest = mySongs[i];
			min = mySongs[i].getRuntime();
			}//if
		}//for
	
	return shortest;
	}//findShortest


/**
 * adds the cost of each song in the playlist
 * 
 * @return	the sum of all costs
 */
public double calcTotalCost()
	{
	int i = 0;
	double total = 0;
	
	for (i = 0; i < mySize; i++)
		{
		total += mySongs[i].getPrice();
		}//for
	
	return total;
	}//calcTotalCost


/**
 * prints a String decription of each song in the playlist
 */
public void printFullPlaylist()
	{
	int i = 0;
	
	if (mySize != 0)
		for (i = 0; i < mySize; i++)
			{
			System.out.println("Song #" + (i + 1) + ":");
			System.out.println(mySongs[i].toString());
			}//for
	else System.out.println("The playlist is empty. Try adding some songs! ");
	
	}//printFullPlaylist


}//PlaylistPotenza
