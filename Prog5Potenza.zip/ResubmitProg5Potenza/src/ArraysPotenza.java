/**
 * @author Amanda Potenza <br>
 * 
 * Prog 5 Resubmit <br>
 * Due Date and Time: 5/1/23 before 10:30am <br>
 * 
 * Purpose: Create a menu where each selection calls a method to analyze arrays
 * 
 * Input: 1,2,3, or 0; integers/doubles into the arrays <br>
 * 
 * Output: analyzes of arrays (more (+) or (-) in arrays/letter grades/avg. or arrays and the number of values >= or < avg.) <br>
 * 
 * Certification of Authenticity: <br>
 * I certify this lab is entirely my own work. <br>
 */

import java.util.*;

public class ArraysPotenza {
	
	//declare keyboard for project
	static Scanner keyboard = new Scanner(System.in);

	public static void main(String[] args) 
	{
		
		//initialize variables
		String fakeChoice = "";
		char choice;
			
		//introduce program
		System.out.println("Welcome! This program will assist you in the following categories. Enter 1,2,3, or 0 to begin.");
			
		//menu
		do
		{
			System.out.println();
			System.out.println("1) More Positives or More Negatives?");
			System.out.println("2) Handle Grades");
			System.out.println("3) How Many Above / Below Average?");
			System.out.println("0) Quit");
		
			System.out.print("Enter choice: ");
			fakeChoice = keyboard.next();
			choice = fakeChoice.charAt(0);
			
			
			switch (choice)
			{
			case '1':
				morePosOrNeg();
				break;
			case '2':
				handleGrades();
				break;
			case '3':
				numAboveOrBelowAvg();
				break;
			case '0':
				System.out.println("Thank you for using this program. Goodbye!");
				break;
			default:
				System.out.println("Invalid. Try again");
			}//switch
		}//do
		while ((choice != '0')); 
			

	keyboard.close();
	}//main
	

/**
 * input up to 10 integers. The code will determine whether there are more positive/negative inputs or if there is a tie
 */
public static void morePosOrNeg()
	{
	
	int [] numbers = new int [10];
	int size = 0;
	int x = 0;
	int posCount = 0;
	int negCount = 0;
	
	//introduce
	System.out.println();
	System.out.println("Input up to 10 integers (one at a time). The code will determine whether there are more positive/negative inputs or if there is a tie.");
	System.out.print("Enter number #" + (size + 1) + ", 0 to quit: ");
	numbers[size] = keyboard.nextInt();
	
	//takes 10 int. inputs - 0 to quit
	while ((size < (numbers.length - 1))&&(numbers[size] != 0))
		{
		size++;
		System.out.print("Enter number #" + (size + 1) + ", 0 to quit: ");
		numbers[size] = keyboard.nextInt();
		}//while
	
	
	//counts # pos/neg.
	for (x = 0; x < size; x++)
		{
		if (numbers[x]>0)
			{
			posCount++;
			}//if
		if (numbers[x]<0)
			{
			negCount++;
			}//if
		}//for
	
	//print results
	if (size == 0)
		System.out.println("You have entered 0 numbers. No data can be shown.");
	else if (posCount > negCount)
		{
		System.out.println("There are more positive numbers: ");
		for (x = 0; x < size; x++)
			if (numbers[x] > 0)
				System.out.print(numbers[x] + " ");
		}//if
	else if (posCount < negCount)
		{
		System.out.println("There are more negative numbers: ");
		for (x = 0; x < size; x++)
			if (numbers[x] < 0)
				System.out.print(numbers[x] + " ");
		}//else if
	else
		{
		System.out.println("There is an equal amount of positive and negative numbers: ");
		for (x = 0; x < (size); x++)
			System.out.print(numbers[x] + " ");
		}//else
	
	System.out.println();
	}//morePosOrNeg
	


/**
 * Input exactly 10 grades. Code will return 1) the highest score and 2) the equivalent letter grade to each number provided
 */
public static void handleGrades()
	{
	double [] numbers = new double [10];
	int x = 0;
	double highest = Double.MIN_VALUE;
	
	//introduce
	System.out.println();
	System.out.println("Input exactly 10 grades (one at a time). The code will return 1) the highest score and 2) the equivalent letter grade to each number provided.");
	
	//take input
	for (x = 0; x < numbers.length; x++)
		{
	 	System.out.print("Enter number #" + (x + 1) + ": ");
		numbers[x] = keyboard.nextDouble();
		}//for
	
	//print highest grade and letter grades
	highest = findHighest(numbers);
	System.out.println("Highest grade: " + highest);
	
	
	System.out.println("Letter grades: ");
	letterGrade(highest, numbers);
	}//handleGrades
	

/**
 * finds the greatest value in an array (used in handleGrades)
 * 
 * @param array the numbers where want to find the max
 * @return the greatest number in the array
 */
public static double findHighest(double [] array)
	{
	double maxSoFar = Double.MIN_VALUE;
	int x = 0;
	
	//find max
	for (x = 0; x < array.length; x++)
		if (array[x] > maxSoFar)
			maxSoFar = array[x];
	
	return maxSoFar;
	}//findHighest


/**
 * assigns letter grade to grades
 * 
 * @param highestGrade the highest grade from the array
 * @param nums the numbers we want to assign letter values to
 */
public static void letterGrade(double highestGrade, double [] nums)
	{
	int x = 0;
	char letterGrade = ' ';
	
	//find letter grade
	for (x = 0; x < nums.length; x++)
		{
		if (nums[x] >= (highestGrade - 10))
			letterGrade = 'A';
		else if (nums[x] >= (highestGrade - 20))
			letterGrade = 'B';
		else if (nums[x] >= (highestGrade - 30))
			letterGrade = 'C';
		else if (nums[x] >= (highestGrade - 40))
			letterGrade = 'D';
		else
			letterGrade = 'F';
		
		System.out.println(nums[x] + " " + letterGrade);
		}//for
	
	}//letterGrade


/**
 * print array, the average value, and the count of elements greater than or equal to the average, along with the count of elements that are less than the average
 */
public static  void numAboveOrBelowAvg()
	{
	double [] numbers = new double [8];
	int x = 0;
	int size = 0;
	double average = 0;
	int amtGreaterThanAvg = 0;
	int amtLessThanAvg = 0;
	
	//introduce
	System.out.println();
	System.out.println("Input up to 8 non-negative numbers (one at a time)."); 
	System.out.println("The code will show the average value, and the count of elements greater than or equal to the average, along with the count of elements that are less than the average.");
	System.out.print("Enter number #" + (size + 1) + ", negative to quit: ");
	numbers[size] = keyboard.nextDouble();
	
	//take 8 int inputs - neg to quit
	while ((size < (numbers.length - 1))&&(numbers[size] >= 0))
		{
		size++;
		System.out.print("Enter number #" + (size + 1) + ", negative to quit: ");
		numbers[size] = keyboard.nextDouble();
		}
	
	for (x = 0; x < size; x++)
		System.out.print(numbers[x] + "  ");
		
	//find average
	average = findAvg(numbers, size);
	
	//count of inputs greater or equal to vs. less than average
	for (x = 0; x < size; x++)
		if (numbers[x] >= average)
			amtGreaterThanAvg++;
		else
			amtLessThanAvg++;
	
	//print data
	if (size == 0)
		System.out.println("There are no numbers in this array. ");		
	else
		{
		System.out.println("Average: " + average);	
		System.out.println("Number of values greater than average: " + amtGreaterThanAvg);
		System.out.println("Number of values less than average: " + amtLessThanAvg);
		}//if

	}//numAboveOrBelowAvg


/**
 * find the average of values in an array
 * 
 * @param nums the numbers we want to find the average of
 * @param size of array
 * @return the average of the numbers in the array
 */
public static double findAvg(double [] nums, int count)
	{
	double sum = 0;
	double avg = 0;
	int x = 0;

	for (x = 0; x < count; x++)
		{
		if (nums[x] >= 0)
			{
			sum += nums[x];
			}//if
		}//for
	
	avg = sum / count;
	
	return avg;
	}//findAvg
}//ArraysPotenza




