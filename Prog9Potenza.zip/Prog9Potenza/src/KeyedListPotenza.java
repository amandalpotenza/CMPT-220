/**
 * 
 * @author amandapotenza
 *
 *This is the class definition for KeyedListPotenza <br>
 *This class holds and stores "items"
 */
public class KeyedListPotenza {
	
	/**
	 * Instance variable for the myItems array
	 */
	private ItemPotenza [] myItems;
	/**
	 * Instance variable for the myItems size
	 */
	private int mySize;

/**
 * The null/default constructor for KeyedListPotenza	
 */
public KeyedListPotenza()
	{
	int i = 0;
	myItems = new ItemPotenza[10];
	for (i = 0; i < myItems.length; i++)
		myItems[i] = null;
	mySize = 0;
	}//PlaylistPotenza

/**
 * the getter for myItems size
 * 
 * @return current value of mySize
 */
public int getSize()
	{
	return mySize;
	}//getMySize

/**
 *clear() clears the array by setting size to 0
 */
public void clear()
	{
	mySize = 0;
	}//clear

/**
 * findIndex() is a private “helper” method to find index of an item if found (otherwise returns -1)
 * 
 * @param keyValue the value we want to find in the list
 * @return returns the array index of an item that is found; otherwise, it returns -1
 */
private int findIndex(String keyValue)
	{
	int i = 0;
	boolean found = false;
	int loc = -1;
	
	while ((i<mySize)&&(!found))
		if (myItems[i].getName().equalsIgnoreCase(keyValue))
			{
			found = true;
			loc = i;
			}//if
		else i++;
	
	return loc;
	}

/**
 * Adds song object to myList array
 * @param product	the new item object we want to add
 * @return	boolean describing whether the song was added or not
 */
public boolean add(ItemPotenza product)
	{
	int i = 0;
	int j = 0;
	boolean success = false;
	
	if ((mySize < myItems.length) && (findIndex(product.getName()) == -1))
		{
		//find the spot
		if (mySize == 0)
			{
			myItems[i] = product;
			mySize++;
			success = true;
			}
		
		else
			{
			while((i < mySize) && (product.getName().compareToIgnoreCase(myItems[i].getName()) > 0))
				i++;
			
			//skootch!
			for (j = mySize - 1; j >= i; j--)
				myItems[j+1] = myItems[j];
			
			//insert value
			myItems[i]= product;
			mySize++;
			success = true;
			}//if
		}//else
	
	return success;
	}//add

/**
 * Deletes song object from myList array
 * 
 * @param keyValue the item name we want to delete
 * @return boolean describing whether the song was deleted or not
 */
public boolean remove(String keyValue)
	{
	int i = findIndex(keyValue);
	boolean success = false;
	int j = 0;
	
	if (i != -1)
		{
		//skootch!
		for(j = i + 1; j < mySize; j++)
			myItems[j-1] = myItems[j];
		mySize--;
		success = true;
		}//if
	
	return success;
	}//remove

/**
 * Returns the item with a specified key value
 * 
 * @param keyValue	 Item name we want to find
 * @return	Corresponding item object, or null if not found
 */
public ItemPotenza retrieve(String keyValue)
	{
	ItemPotenza match = null;
	int i = 0;
	
	while ((i < mySize) && (match == null))
		{
		if (keyValue.equalsIgnoreCase(myItems[i].getName()))
			match = myItems[i];
		else i++;
		}//while
	
	return match;
	}//retrieve

/**
 * Tells whether or not myList is empty
 * 
 * @return boolean telling if the list is empty or not
 */
public boolean isEmpty()
	{
	boolean empty = false;
	
	if (mySize == 0)
		empty = true;
		
	return empty; 
	}//isEmpty

/**
 * Tells whether or not myList is full
 * 
 * @return boolean telling if the list is full or not
 */
public boolean isFull()
	{
	boolean full = false;
	
	if (mySize == myItems.length)
		full = true;
		
	return full; 
	}//isFull

/**
 * prints a String decription of each item in the list
 */
public void print()
	{
	int i = 0;
	
	if (mySize != 0)
		for (i = 0; i < mySize; i++)
			{
			System.out.println("Item #" + (i + 1) + ":");
			System.out.println(myItems[i].toString());
			}//for
	else System.out.println("The shopping list is empty. Try adding some items! ");
	
	}//print

/**
 * Finds total number of items in list
 * @return	total item count
 */
public int getCount()
	{
	int count = 0;
	int i = 0;
	
	if (mySize != 0)
		for (i = 0; i < mySize; i++)
			{
			count += myItems[i].getQuantity();
			}//for
	
	return count;
	}//getCount

/**
 * Finds total cost of items in list
 * @return total cost of items
 */
public double calcTotal()
	{
	double total = 0.0;
	int i = 0;
	
	if (mySize != 0)
		for (i = 0; i < mySize; i++)
			{
			total += (myItems[i].getQuantity() * myItems[i].getPrice());
			}//for
	
	return total;
	}//getCount



}//KeyedListPotenza
