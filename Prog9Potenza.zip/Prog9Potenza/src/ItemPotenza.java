/**
 * 
 * @author Amanda Potenza <br>
 *
 *This is the class definition for ItemPotenza <br>
 *this item class allows users to create a item object with a name, quantity, and price
 */

public class ItemPotenza {

	/**
	 * instance variable for song's name
	 */
	private String myName;
	/**
	 * instance variable for song's quantity
	 */
	private int myQuantity;
	/**
	 * instance variable for song's price
	 */
	private double myPrice;
	
/**
 * the null/default constructor for ItemPotenza
 */
public ItemPotenza()
	{
	myName = "None";
	myQuantity = 0;
	myPrice = 0.0;
	}//null constructor


/**
 * Full constructor for ItemPotenza
 * 
 * @param name	New name for item
 * @param quantity	New quantity for item
 * @param price	New unit price for item
 */
public ItemPotenza(String name, int quantity, double price)
	{
	myName = name;
	myQuantity = quantity;
	myPrice = price;
	}//full constructor


/**
 * setter for item name
 * 
 * @param name	new name for the item
 */
public void setName(String name)
	{
	myName = name;
	}//setName

/**
 * setter for quantity
 * 
 * @param quantity	new quantity for the item
 */
public void setQuantity(int quantity)
	{
	myQuantity = quantity;
	}//setQuantity

/**
 * setter for price
 * 
 * @param price	new price for the item
 */
public void setPrice(double price)
	{
	myPrice = price;
	}//setPrice


/**
 * getter for name
 * 
 * @return current value for name
 */
public String getName()
	{
	return myName;
	}//getName

/**getter for quantity
 * 
 * @return current value for quantity
 */
public int getQuantity()
	{
	return myQuantity;
	}//getQuantity

/**
 * current value for price
 * 
 * @return myPrice
 */
public double getPrice()
	{
	return myPrice;
	}//getPrice


/**
 * The toString method for ItemPotenza
 * 
 * @return	a String describing the item's instance variables
 */
public String toString()
	{
	String ans = "Name: " + myName + "\n";
	ans+= "Quantity: " + myQuantity + "\n";
	ans += "Price: $" + String.format("%.2f", myPrice) + "\n";
	
	return ans;
	}//toString


}//ItemPotenza
