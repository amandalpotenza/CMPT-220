/**
 * @author Amanda Potenza <br>
 * 
 * Prog 9 <br>
 * Due Date and Time: 4/6/23 before 10:30am <br>
 * 
 * Purpose: This program stores objects in a keyedList array. We will use file input to add songs initially. You can interact with this list using different methods in the classes.
 * 
 * Input: File name, Menu option, Item name, quantity, price <br>
 * 
 * Output: description of all items, specific item description, total count, total cost, whether list is empty or full, feedback for each option <br>
 * 
 * Certification of Authenticity: <br>
 * 	I certify this lab is entirely my own work. <br>
 */


//Use import to gain access to Java utility classes for file input/output.
import java.io.*;
import java.util.*;

public class ShoppingDemoPotenza {

	//declare keyboard for project
	static Scanner keyboard = new Scanner(System.in);
	
	public static void main(String[] args) 
		{
	
		//initialize variables
		int choice;
		String itemName = "None";
		ItemPotenza item = null;
		KeyedListPotenza keyedList = new KeyedListPotenza();
		
		System.out.println("Welcome to this shopping program! ");
		fileAdd(keyedList);
		
		// create a menu
		do
			{
			System.out.println();
			System.out.println("--------------------------");
			System.out.println();
			
			System.out.println("1. Add an item to the list");
			System.out.println("2. Delete an item from the list");
			System.out.println("3. Print each item in the list ");
			System.out.println("4. Search for a user-specified item in the list");
			System.out.println("5. Count the total number of items in the list");
			System.out.println("6. Total the cost of the items in the list");
			System.out.println("7. Determine whether the list is empty");
			System.out.println("8. Determine whether the list is full");
			System.out.println("9. Clear the list");
			System.out.println("0 - Quit");
			System.out.println();
			System.out.println("Enter here:");
			choice = keyboard.nextInt();
			
			switch (choice)
				{
				case 1:
					optionAdd(keyedList);
					break;
				case 2:
					optionDelete(keyedList);
					break;
				case 3:
					keyedList.print();
					break;
				case 4:
					System.out.print("Enter name of item to search: ");
					itemName = keyboard.next();
					item = keyedList.retrieve(itemName);
					if (item != null)
						{
						System.out.println("\nThis item is in your cart!");
						System.out.println(item.toString());
						}
					else System.out.println("\nThis item is not in your cart!");
					break;
				case 5:
					System.out.println("\nTotal items in cart: " + keyedList.getCount());
					if (keyedList.getCount() == 0)
						System.out.println("The shopping list is empty. Try adding some items! ");
					break;
				case 6:
					System.out.printf("\nThe total cost of all the items is: $%.2f", keyedList.calcTotal());
					if (keyedList.calcTotal() == 0.0)
						System.out.println("\nThe shopping list is empty. Try adding some items! ");
					break;
				case 7:
					if (keyedList.isEmpty() == true)
						System.out.println("\nList is empty! ");
					else System.out.print("\nList is not empty!");
					break;
				case 8:
					if (keyedList.isFull() == true)
						System.out.println("\nList is full! ");
					else System.out.println("\nList is not full!");					
					break;
				case 9:
					keyedList.clear();
					System.out.println("\nList is cleared.");
					break;
				case 0:
					System.out.println();
					System.out.println("Thank you for using this program! Goodbye.");
					break;
				default:
				}//switch
			}//do
		while (choice != 0);
		
		
		 keyboard.close();
		}//main
	
	
/**
 * optionAdd calls the add method and validates the input before successfully adding the new item to the keyedList array  
 * @param list		list is our keyedList array where the song will be added
 */
public static void optionAdd(KeyedListPotenza list)
	{
	//initialize variables
	ItemPotenza newItem = null;
	String name = "none";
	int quantity = 0;
	double price = 0.0;
	boolean ok = false;
	
	
	//prompt user to input song variables and validate them
	System.out.println("Enter name of item: ");
	name = keyboard.next();

	do 
		{
		System.out.println("Enter quantity: ");
		quantity = keyboard.nextInt();
		}//do
	while (quantity <= 0);
	
	do
		{
		System.out.println("Enter unit price: ");
		System.out.print("$");
		price = keyboard.nextDouble();
		}//do
	while (price <= 0);

	
	//create new item object and print if it was added or not
	newItem = new ItemPotenza(name, quantity, price);
	ok = list.add(newItem);
	
	if (ok == true)
		 System.out.println("The item has been added!");
	else System.out.println("Error: item could not be added.");
	}//optionAdd
	

/**
 * fileAdd reads a .txt file to inputs items
 * @param list		list is our keyedList array where the song will be added
 */
public static void fileAdd(KeyedListPotenza list)
	{
	//initialize variables
	ItemPotenza newItem = null;
	String name = "none";
	int quantity = 0;
	double price = 0.0;
	int numItems = 0;
	String filename = null;
	int i = 0;
	
	System.out.print("Enter the name of your initial input file:  ");
    filename = keyboard.next(); 
    
	//create the reference to the file, declared up here because of the "catch"
    File inputFile = new File(filename);
	
	try 
		{
		//Create a second Scanner object, this one for reading from the file
	    Scanner input = new Scanner(inputFile);
		
	    numItems = input.nextInt();
	    
	    if (numItems <= 10)
		    {
		    for (i = 0; i < numItems; i++)
		    	{
				name = input.next();
				do 
					{
					quantity = input.nextInt();
					}//do
				while (quantity <= 0);
				do
					{
					price = input.nextDouble();
					}//do
				while (price <= 0);
		
				
				//create new  object and print if it was added or not
				newItem = new ItemPotenza(name, quantity, price);
				list.add(newItem);
		    	}//for
		    }//if
	    else System.out.println("Error adding items. Limit has already been reached. Try editing your file document.");
		
		////close input Scanner
	      input.close();
		}//try
	
	catch(FileNotFoundException ex)
	    {
	      System.out.println("Failed to find file: " + inputFile.getAbsolutePath()); 
	      System.out.println("Try rerunning the program or entering the songs manually below.");
	    }//catch
    catch(InputMismatchException ex)
	    {
	    System.out.println("Type mismatch for the number I just tried to read.");
	    System.out.println(ex.getMessage());
	    }
    catch(NumberFormatException ex)
	    {
	    System.out.println("Failed to convert String text into an integer value.");
	    System.out.println(ex.getMessage());
	    }//catch
    catch(NullPointerException ex)
	    {
	    System.out.println("Null pointer exception.");
	    System.out.println(ex.getMessage());
	    }//catch
	catch(Exception ex)
	    {
	    System.out.println("Something went wrong");
	    ex.printStackTrace();
	    }//catch
	
	}//fileOptionAdd


/**
 * optionDelete calls the delete method and deletes the specific item from the keyedList array
 * @param list		list is our keyedList array where the song will be removed
 */
public static void optionDelete(KeyedListPotenza list)
	{
	//initialize variables
	String name = "none";
	boolean ok = false;
	
	//prompt user to input variables 
	System.out.println("Enter name of item: ");
	name = keyboard.next();
	
	//create new item object and print if it was added or not
	ok = list.remove(name);
	
	if (ok == true)
		 System.out.println("The item has been deleted!");
	else System.out.println("Error deleting item. Item cannot be found.");
	}//optionDelete

}//ShoppingDemoPotenza
